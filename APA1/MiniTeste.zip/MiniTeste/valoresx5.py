values=[2,3,5,7,11]

vals = []
for element in values:
    vals.append(element*5)
values=vals

for element in values:
    print(element)