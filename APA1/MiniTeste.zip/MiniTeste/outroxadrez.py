Str = 'a3' 

if (Str[0]==("a" or "c" or "e" or "g") and Str[1]==("1" or "3" or "5" or "7")):
   print ("Black")
else:
   print("White")